# Flutter Login & Signup UI

A Flutter project for YouTube tutorial. Here I have created layout of a Landing/Getting Started screen for the App and Login & Signup Screens.

## Getting Started Screen

This is a landing or gettting started screen of the app, where I have used PageView widget to give a sliding effect of a section of the screen and it has automatic transition effect. For more details [please see the tutorial here](https://youtu.be/oS7iK5ivgD0).

![Getting Started Screen](https://www.pradipdebnath.com/wp-content/uploads/2019/09/flutter-app-getting-started-screen.png)

## Login & Signup Screen

Login & signup screens in flutter. To know more in details [please follow this YouTube tutorial](https://youtu.be/OqO5wjMkaHo).

![Login Screen](https://www.pradipdebnath.com/wp-content/uploads/2019/09/flutter-app-login-screen.png) ![Signup Screen](https://www.pradipdebnath.com/wp-content/uploads/2019/09/flutter-app-signup-screen.png)
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

Future<Cities> getCities() async {
  final response = await http.get('https://peaku.co/api-v2/get-cities');
  if (response.statusCode == 200) {
    return Cities.fromJson(json.decode(response.body));
  } else {
    throw Exception('Failed to load cities');
  }
}

class Cities {
  final int pk;
  final bool home;
  final String name;

  Cities({this.pk, this.home, this.name});

  factory Cities.fromJson(Map<String, dynamic> json) {
    return Cities(
      pk: json['pk'],
      name: json['name'],
      home: json['is_home'],
    );
  }
}

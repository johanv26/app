import 'package:flutter/material.dart';

class LandingScreen extends StatefulWidget {
  @override
  _LandingScreenState createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  int _selectedIndex = 0;

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        title: Container(
                  padding: EdgeInsets.fromLTRB(10.0, 10.0, 0, 0),
                  child: Row(
                    children: [
                        Text('Hola  ',
                            style: TextStyle(
                            fontFamily: 'Monserrat',
                            fontStyle: FontStyle.normal,
                            color: Colors.black,
                            fontSize: 25,
                          ),
                        ),
                      Text('Juan',
                        style: TextStyle(
                          fontFamily: 'Monserrat',
                          fontStyle: FontStyle.normal,
                          color: Color(0xff1d976c),
                          fontSize: 25,
                        ),
                      ),
                    ],
                  ),
        ),
        leading: Container(
          margin: EdgeInsets.only(left: 10.0, top:10.0),
          child: CircleAvatar(
            backgroundImage: NetworkImage('https://cdn.techinasia.com/wp-content/uploads/2016/02/pawel-netreba-bfab.jpg'),
          ),
        ),
      ),
      body: ofertaNueva(),

      bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
                      BottomNavigationBarItem(
                        icon: Icon(Icons.accessibility),
                        title: Text('Perfil'),
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.school),
                        title: Text('Pruebas'),
                      ),
                      BottomNavigationBarItem(
                        icon: Icon(Icons.description),
                        title: Text('Mis Ofertas'),
                      ),
                      ],
                      currentIndex: _selectedIndex,
                      selectedItemColor: Color(0xff1d976c),
                      onTap: _onItemTapped,
    ),
    );
  }
  Widget ofertaNueva() {
    return ListView(
      padding: EdgeInsets.all(130.0),
       children: [
         Center(child: Text('Desarrollador BackEnd', style: TextStyle(
           fontFamily: 'Monserrat',
           fontStyle: FontStyle.normal,
           fontSize: 20,
         ),
         )
         ),
         Container(
           decoration: BoxDecoration(
               boxShadow: <BoxShadow>[
               ]
           ),
           child: ClipRRect(
             borderRadius: BorderRadius.circular(20.0),
             child: Container(
               child: Column(
                 children: <Widget>[
                   FadeInImage(
                       fit: BoxFit.contain,
                       placeholder: AssetImage('assets/images/cargando.gif'),
                       image: NetworkImage(
                           'https://wallpaperaccess.com/full/1356240.jpg'))
                 ],
               ),
             ),
           ),
         ),
       ],
    );
  }
}


